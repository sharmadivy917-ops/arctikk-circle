<?php if (!defined('ABSPATH')) exit; ?>
<div id="yclp-wrap">

  <!-- LOGIN -->
  <div id="yclp-login" style="display:flex;">
    <div class="yclp-login-box">
      <div class="yclp-login-logo">
        <img src="https://arctikkcircle.in/wp-content/uploads/2026/03/Asset2_ywotg_3701.png" alt="ArctikkCircle" onerror="this.style.display='none'">
        <h2>YCLP Admin</h2>
        <p>Workshop & OTO Dashboard</p>
      </div>
      <div class="yclp-login-form">
        <input type="password" id="yclp-pass" placeholder="Enter admin password">
        <button id="yclp-login-btn">Login →</button>
        <p id="yclp-login-err" class="yclp-err" style="display:none;">Wrong password. Try again.</p>
      </div>
    </div>
  </div>

  <!-- DASHBOARD -->
  <div id="yclp-dashboard" style="display:none;">

    <!-- TOPBAR -->
    <div class="yclp-topbar">
      <div class="yclp-topbar-left">
        <span class="yclp-logo-text">⚡ YCLP Admin</span>
        <span class="yclp-version">v2.3.0</span>
      </div>
      <div class="yclp-topbar-right">
        <button class="yclp-tab-btn active" data-tab="registrations">📝 Registrations</button>
        <button class="yclp-tab-btn" data-tab="bookings">📅 OTO Bookings</button>
        <button class="yclp-tab-btn" data-tab="calendar">🗓 Calendar</button>
        <button class="yclp-tab-btn" data-tab="revenue">💰 Revenue</button>
        <button class="yclp-tab-btn" data-tab="landingpage">🌐 Landing Page</button>
        <button class="yclp-tab-btn" data-tab="settings">⚙️ Settings</button>
        <button id="yclp-logout-btn" class="yclp-logout">Logout</button>
      </div>
    </div>

    <!-- STATS BAR -->
    <div class="yclp-stats-bar">
      <div class="yclp-stat">
        <span class="yclp-stat-val" id="stat-reg-total">—</span>
        <span class="yclp-stat-lbl">Workshop Registrations</span>
      </div>
      <div class="yclp-stat">
        <span class="yclp-stat-val green" id="stat-reg-paid">—</span>
        <span class="yclp-stat-lbl">Paid Registrations</span>
      </div>
      <div class="yclp-stat">
        <span class="yclp-stat-val red" id="stat-reg-revenue">—</span>
        <span class="yclp-stat-lbl">Workshop Revenue</span>
      </div>
      <div class="yclp-stat">
        <span class="yclp-stat-val orange" id="stat-oto-paid">—</span>
        <span class="yclp-stat-lbl">OTO Sessions Booked</span>
      </div>
    </div>

    <!-- TAB: REGISTRATIONS -->
    <div class="yclp-tab-content" id="tab-registrations">
      <div class="yclp-toolbar">
        <input type="text" id="reg-search" placeholder="🔍 Search name, email, phone, city…">
        <select id="reg-filter-status">
          <option value="">All Status</option>
          <option value="PAID">Paid ✅</option>
          <option value="Pending">Pending</option>
          <option value="Cancelled">Cancelled ❌</option>
          <option value="Abandoned">Abandoned ⚠️</option>
        </select>
        <button id="reg-export-btn" class="yclp-btn-green">⬇ Export CSV</button>
        <button id="reg-refresh-btn" class="yclp-btn-blue">↻ Refresh</button>
        <button id="reg-bulk-delete-btn" class="yclp-btn-red" style="display:none;">🗑 Delete Selected</button>
        <button id="reg-reset-btn" class="yclp-btn-red" onclick="resetAllRegistrations()">⚠️ Reset All</button>
      </div>
      <div class="yclp-count" id="reg-count"></div>
      <div class="yclp-table-wrap">
        <table id="yclp-reg-table">
          <thead>
            <tr>
              <th><input type="checkbox" id="reg-select-all" title="Select All"></th>
              <th>#</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Std</th>
              <th>City</th>
              <th>Workshop Date</th>
              <th>Package</th>
              <th>📘 Ebook</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Payment ID</th>
              <th>Registered On</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="yclp-reg-body">
            <tr><td colspan="14" class="yclp-loading">Loading registrations…</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB: OTO BOOKINGS -->
    <div class="yclp-tab-content" id="tab-bookings" style="display:none;">
      <div class="yclp-toolbar">
        <input type="text" id="yclp-search" placeholder="🔍 Search name, email, phone…">
        <select id="yclp-filter-status">
          <option value="">All Status</option>
          <option value="OTO PAID ✅">Paid ✅</option>
          <option value="OTO — Payment Pending">Pending</option>
          <option value="OTO Cancelled ❌">Cancelled ❌</option>
          <option value="OTO Skipped 🚫">Skipped</option>
        </select>
        <input type="date" id="yclp-filter-date" title="Filter by session date">
        <button id="yclp-export-btn" class="yclp-btn-green">⬇ Export CSV</button>
        <button id="yclp-refresh-btn" class="yclp-btn-blue">↻ Refresh</button>
        <button id="oto-bulk-delete-btn" class="yclp-btn-red" style="display:none;">🗑 Delete Selected</button>
        <button id="oto-reset-btn" class="yclp-btn-red" onclick="resetAllBookings()">⚠️ Reset All</button>
      </div>
      <div class="yclp-count" id="yclp-count"></div>
      <div class="yclp-table-wrap">
        <table id="yclp-bookings-table">
          <thead>
            <tr>
              <th><input type="checkbox" id="oto-select-all" title="Select All"></th>
              <th>#</th>
              <th>Name</th>
              <th>Phone</th>
              <th>Email</th>
              <th>Std</th>
              <th>📅 Session Date</th>
              <th>⏰ Time</th>
              <th>Amount</th>
              <th>Status</th>
              <th>Payment ID</th>
              <th>Booked On</th>
              <th>Actions</th>
            </tr>
          </thead>
          <tbody id="yclp-bookings-body">
            <tr><td colspan="12" class="yclp-loading">Loading bookings…</td></tr>
          </tbody>
        </table>
      </div>
    </div>

    <!-- TAB: CALENDAR -->
    <div class="yclp-tab-content" id="tab-calendar" style="display:none;">
      <div class="yclp-section-header">
        <h3>🗓 OTO Booking Calendar</h3>
        <div style="display:flex;gap:10px;align-items:center;">
          <button class="yclp-btn-blue" id="cal-prev">‹ Prev</button>
          <span id="cal-month-label" style="font-weight:800;color:#fff;min-width:160px;text-align:center;font-size:1rem;"></span>
          <button class="yclp-btn-blue" id="cal-next">Next ›</button>
        </div>
      </div>
      <div class="cal-legend">
        <span class="leg-item"><span class="leg-dot" style="background:#16a34a;"></span> Fully Booked</span>
        <span class="leg-item"><span class="leg-dot" style="background:#e8b84b;"></span> Partially Booked</span>
        <span class="leg-item"><span class="leg-dot" style="background:#2563eb;"></span> Today</span>
      </div>
      <div class="cal-main-wrapper">
        <div class="cal-left-col">
          <div class="admin-calendar" id="adminCal">
            <div class="admin-cal-header">
              <div class="admin-cal-dayname">Sun</div><div class="admin-cal-dayname">Mon</div>
              <div class="admin-cal-dayname">Tue</div><div class="admin-cal-dayname">Wed</div>
              <div class="admin-cal-dayname">Thu</div><div class="admin-cal-dayname">Fri</div>
              <div class="admin-cal-dayname">Sat</div>
            </div>
            <div class="admin-cal-days" id="adminCalDays">
              <div style="grid-column:1/-1;text-align:center;padding:40px;color:#888;">Loading calendar…</div>
            </div>
          </div>
        </div>
        <div class="slot-side-panel" id="slotDetail">
          <div class="slot-panel-empty" id="slotPanelEmpty">
            <div style="font-size:2.5rem;margin-bottom:12px;">📅</div>
            <p style="color:#888;font-size:.9rem;line-height:1.6;">Click on any date<br>to see slot details</p>
          </div>
          <div id="slotPanelContent" style="display:none;">
            <h4 id="slotDetailDate" style="color:#fff;margin:0 0 4px;font-size:1rem;font-weight:800;"></h4>
            <p id="slotDetailSummary" style="color:#888;font-size:.78rem;margin:0 0 16px;"></p>
            <hr style="border:0;border-top:1px solid rgba(255,255,255,.08);margin-bottom:16px;">
            <div class="slot-grid-admin" id="slotGridAdmin"></div>
            <div id="entryInfoTable" style="display:none;margin-top:20px;padding-top:20px;border-top:1px solid rgba(255,255,255,.08);">
              <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;">
                <h5 style="color:#e8b84b;margin:0;font-size:.85rem;">📋 Parent Details</h5>
                <button onclick="document.getElementById('entryInfoTable').style.display='none'" style="background:none;border:none;color:#888;cursor:pointer;font-size:.8rem;padding:2px 6px;">✕</button>
              </div>
              <div class="entry-detail-card">
                <div class="edc-row"><span class="edc-lbl">Name</span><span class="edc-val" id="det-name"></span></div>
                <div class="edc-row"><span class="edc-lbl">Phone</span><span class="edc-val" id="det-phone"></span></div>
                <div class="edc-row"><span class="edc-lbl">Email</span><span class="edc-val" id="det-email" style="font-size:.73rem;"></span></div>
                <div class="edc-row"><span class="edc-lbl">Standard</span><span class="edc-val" id="det-std"></span></div>
                <div class="edc-row"><span class="edc-lbl">Status</span><span class="edc-val" id="det-status"></span></div>
                <div class="edc-row"><span class="edc-lbl">Payment ID</span><span class="edc-val" id="det-payment" style="font-size:.7rem;word-break:break-all;"></span></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <!-- TAB: REVENUE -->
    <div class="yclp-tab-content" id="tab-revenue" style="display:none;">
      <div class="yclp-section-header">
        <h3>💰 Revenue Overview</h3>
        <span style="font-size:.8rem;color:#888;">Live from database</span>
      </div>
      <div class="yclp-revenue-grid">
        <div class="yclp-revenue-card">
          <div class="yclp-rc-icon">💰</div>
          <div class="yclp-rc-val" id="rev-total-revenue">—</div>
          <div class="yclp-rc-lbl">Total Workshop Revenue</div>
        </div>
        <div class="yclp-revenue-card">
          <div class="yclp-rc-icon">✅</div>
          <div class="yclp-rc-val" id="rev-paid-count">—</div>
          <div class="yclp-rc-lbl">Paid Registrations</div>
        </div>
        <div class="yclp-revenue-card">
          <div class="yclp-rc-icon">⏳</div>
          <div class="yclp-rc-val" id="rev-pending-count">—</div>
          <div class="yclp-rc-lbl">Pending / Abandoned</div>
        </div>
        <div class="yclp-revenue-card">
          <div class="yclp-rc-icon">📗</div>
          <div class="yclp-rc-val" id="rev-ebook-count">—</div>
          <div class="yclp-rc-lbl">Ebook Add-ons Sold</div>
        </div>
      </div>
      <div style="margin-top:28px;">
        <h4 style="color:#fff;font-size:.9rem;font-weight:700;margin:0 0 14px;">Conversion Funnel</h4>
        <div id="yclp-session-breakdown"></div>
      </div>
      <div style="margin-top:28px;">
        <h4 style="color:#fff;font-size:.9rem;font-weight:700;margin:0 0 14px;">Recent Paid Registrations</h4>
        <div class="yclp-table-wrap">
          <table style="width:100%;border-collapse:collapse;background:#fff;font-size:.83rem;">
            <thead>
              <tr>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">Name</th>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">Phone</th>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">City</th>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">Package</th>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">Amount</th>
                <th style="padding:10px 14px;text-align:left;background:#0f0f0f;color:#fff;font-size:.72rem;text-transform:uppercase;letter-spacing:.06em;">Payment ID</th>
              </tr>
            </thead>
            <tbody id="yclp-rev-body">
              <tr><td colspan="6" style="text-align:center;padding:30px;color:#888;">Loading…</td></tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>

    <!-- TAB: LANDING PAGE -->
    <div class="yclp-tab-content" id="tab-landingpage" style="display:none;">
      <div class="yclp-section-header">
        <h3>🌐 Landing Page Preview</h3>
        <div style="display:flex;gap:10px;align-items:center;">
          <button class="lp-device-btn lp-active" id="lp-btn-desktop" onclick="yclpSetLPWidth('100%','desktop')">💻 Desktop</button>
          <button class="lp-device-btn" id="lp-btn-tablet" onclick="yclpSetLPWidth('768px','tablet')">📱 Tablet</button>
          <button class="lp-device-btn" id="lp-btn-mobile" onclick="yclpSetLPWidth('390px','mobile')">📲 Mobile</button>
          <a href="https://arctikkcircle.in/" target="_blank" class="yclp-btn-green" style="text-decoration:none;font-size:.82rem;">↗ New Tab</a>
          <button class="yclp-btn-blue" onclick="var f=document.getElementById('lp-iframe');f.src=f.getAttribute('data-src');" style="font-size:.82rem;">↻ Reload</button>
        </div>
      </div>
      <div style="background:#1a1a1a;border:1px solid rgba(255,255,255,.08);border-radius:10px;overflow:hidden;display:flex;justify-content:center;">
        <iframe id="lp-iframe" src="about:blank" data-src="https://arctikkcircle.in/"
          style="width:100%;min-height:85vh;border:none;display:block;transition:width .3s;"
          title="YCLP Landing Page"></iframe>
      </div>
    </div>

    <!-- TAB: SETTINGS -->
    <div class="yclp-tab-content" id="tab-settings" style="display:none;">
      <div class="yclp-section-header">
        <h3>⚙️ Settings & Configuration</h3>
      </div>
      <div class="yclp-settings-grid">

        <div class="yclp-settings-card">
          <h4>🔒 Change Admin Password</h4>
          <p>Update the password used to access this dashboard.</p>
          <input type="password" id="new-pass-1" placeholder="New password (min 6 chars)">
          <input type="password" id="new-pass-2" placeholder="Confirm new password">
          <button class="yclp-btn-red" onclick="changePassword()" style="width:100%;margin-top:4px;">Update Password</button>
          <p id="pw-msg" style="margin-top:10px;font-size:.82rem;display:none;"></p>
        </div>

        <div class="yclp-settings-card">
          <h4>🔗 API Endpoints</h4>
          <p>Use these endpoints in your frontend scripts.</p>
          <div class="api-endpoint-list">
            <div class="api-ep-item"><span class="api-ep-method post">POST</span><code id="yclp-api-reg"></code></div>
            <div class="api-ep-item"><span class="api-ep-method post">POST</span><code id="yclp-api-book"></code></div>
            <div class="api-ep-item"><span class="api-ep-method get">GET</span><code id="yclp-api-slots"></code></div>
            <div class="api-ep-item"><span class="api-ep-method get">GET</span><code id="yclp-api-dates"></code></div>
          </div>
        </div>

        <div class="yclp-settings-card">
          <h4>🕐 OTO Time Slots (12 PM – 8 PM)</h4>
          <p>Edit in <code style="background:#1a1a1a;padding:2px 6px;border-radius:4px;font-size:.8rem;">yclp-admin.php</code> → <code style="background:#1a1a1a;padding:2px 6px;border-radius:4px;font-size:.8rem;">YCLP_SLOTS</code></p>
          <div id="slots-preview" style="display:flex;flex-wrap:wrap;gap:8px;margin-top:8px;"></div>
        </div>

        <div class="yclp-settings-card">
          <h4>ℹ️ System Info</h4>
          <p>Plugin and database details.</p>
          <div class="entry-detail-card">
            <div class="edc-row"><span class="edc-lbl">Version</span><span class="edc-val">v2.3.0</span></div>
            <div class="edc-row"><span class="edc-lbl">OTO Slots/Day</span><span class="edc-val" id="info-total-slots">—</span></div>
            <div class="edc-row"><span class="edc-lbl">Registrations Table</span><span class="edc-val" style="font-size:.75rem;">wp_yclp_registrations</span></div>
            <div class="edc-row"><span class="edc-lbl">OTO Bookings Table</span><span class="edc-val" style="font-size:.75rem;">wp_yclp_oto_bookings</span></div>
            <div class="edc-row"><span class="edc-lbl">Slots Table</span><span class="edc-val" style="font-size:.75rem;">wp_yclp_booked_slots</span></div>
          </div>
        </div>

      </div>
    </div>

  </div><!-- /#yclp-dashboard -->

  <!-- STATUS MODAL -->
  <div id="status-modal" class="yclp-modal-overlay" style="display:none;">
    <div class="yclp-modal">
      <h4>✏️ Update Status</h4>
      <p style="color:#888;font-size:.85rem;margin:0 0 14px;">ID: <span id="status-modal-id" style="color:#fff;font-weight:700;"></span></p>
      <input type="hidden" id="status-modal-table" value="oto">
      <select id="status-modal-select"></select>
      <div class="yclp-modal-btns">
        <button class="yclp-btn-red" onclick="closeStatusModal()">Cancel</button>
        <button class="yclp-btn-green" onclick="confirmStatusUpdate()">Update →</button>
      </div>
    </div>
  </div>

  <!-- MANUAL OTO BOOKING MODAL -->
  <div id="manual-booking-modal" class="yclp-modal-overlay" style="display:none;">
    <div class="yclp-modal">
      <h4>➕ Add Manual OTO Booking</h4>
      <div class="mb-slot-badge" id="mb-slot-info"></div>
      <input type="text"  id="mb-fname"    placeholder="First Name *">
      <input type="text"  id="mb-lname"    placeholder="Last Name">
      <input type="email" id="mb-email"    placeholder="Email *">
      <input type="text"  id="mb-phone"    placeholder="Phone">
      <input type="text"  id="mb-standard" placeholder="Child's Standard">
      <div class="yclp-modal-btns">
        <button class="yclp-btn-red"   onclick="window.closeManualBooking()">Cancel</button>
        <button class="yclp-btn-green" id="mb-save-btn" onclick="window.submitManualBooking()">Save Booking ✅</button>
      </div>
    </div>
  </div>

</div><!-- /#yclp-wrap -->