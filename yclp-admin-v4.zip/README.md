# YCLP Admin Dashboard v2.3.0
## Installation & Setup

---

## STEP 1 — Install Plugin
Go to: WordPress → Plugins → Add New → Upload Plugin
Upload: yclp-admin.zip → Install → Activate

Dashboard opens at: arctikkcircle.in/yclp-admin
Default password: Arctikk@2026

This version creates THREE database tables:
- wp_yclp_registrations    ← workshop signups from landing page
- wp_yclp_oto_bookings     ← OTO consultation bookings
- wp_yclp_booked_slots     ← fast slot lock table for OTO

---

## STEP 2 — Fix Landing Page Script

In your landing page payment JS, make TWO changes:

### 2a. Fix the WP_API_URL (was pointing to wrong endpoint):
WRONG:   const WP_API_URL = 'https://arctikkcircle.in/wp-json/yclp/v1/register';  ← already correct now!
CORRECT: const WP_API_URL = 'https://arctikkcircle.in/wp-json/yclp/v1/register';

The /register endpoint now exists in v2.3.0. No change needed.

### 2b. Redirect to OTO page after successful payment:
In the Razorpay handler success block, make sure it redirects to your OTO page:

  handler: function(response){
    // ... save data ...
    setTimeout(function(){
      window.location.href = 'https://arctikkcircle.in/oto/'
        + '?payment_id=' + response.razorpay_payment_id
        + '&fname='      + encodeURIComponent(fname);
    }, 2000);
  }

This redirect is already in your landing page JS. Make sure the OTO page URL is correct.

---

## STEP 3 — Update Google Apps Script

1. Open your Google Sheet
2. Extensions → Apps Script → Delete old code
3. Paste: includes/google-apps-script.gs
4. Deploy → New Deployment → Web App (Execute as: Me, Access: Anyone)
5. Copy the new URL → update SHEET_URL in landing page JS

---

## STEP 4 — Update OTO Page Calendar Script

Replace the <script> block in your OTO page with:
includes/oto-calendar-script.html

- Calendar minimum = day after tomorrow
- Slots: 12:00 PM to 8:00 PM (9 slots)
- Booked slots shown in red, fully booked dates greyed out
- Slot locked in DB + Sheets on payment

---

## Dashboard Tabs

| Tab | What it shows |
|-----|---------------|
| 📝 Registrations | All YCLP workshop signups. Name, phone, email, city, standard, package, ebook add-on, amount, status. Search, filter, export CSV. |
| 📅 OTO Bookings | OTO consultation bookings with date + time slot. Filter by date/status. |
| 🗓 Calendar | Visual month view of OTO slots. Green = full, Gold = partial. Click to see/add bookings. |
| 💰 Revenue | Workshop revenue, paid count, conversion funnel, ebook sales. |
| 🌐 Landing Page | Live preview of arctikkcircle.in with Desktop/Tablet/Mobile toggle. |
| ⚙️ Settings | Change password, API endpoints, slot list. |

---

## OTO Time Slots (12 PM – 8 PM, 9 slots/day)
12:00 PM, 1:00 PM, 2:00 PM, 3:00 PM, 4:00 PM, 5:00 PM, 6:00 PM, 7:00 PM, 8:00 PM

---

## Changes in v2.3.0
- NEW: wp_yclp_registrations table — stores all landing page workshop signups
- NEW: /yclp/v1/register REST endpoint — correct URL for landing page WP_API_URL
- NEW: 📝 Registrations tab — shows all workshop signups with full details (city, package, ebook)
- FIXED: Slots reverted to 12 PM – 8 PM (9 slots, as intended)
- FIXED: Revenue tab now shows workshop revenue and ebook add-on count
- FIXED: Status modal works for both registrations and OTO bookings separately
- UPDATED: Stats bar now shows Workshop Registrations + Paid + Revenue + OTO Sessions
