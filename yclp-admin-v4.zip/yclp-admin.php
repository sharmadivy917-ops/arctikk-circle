<?php
/**
 * Plugin Name: YCLP OTO Admin Dashboard
 * Description: Frontend admin dashboard for YCLP workshop registrations and OTO consultation bookings.
 * Version: 2.3.1
 * Author: ArctikkCircle
 */

if (!defined('ABSPATH')) exit;

define('YCLP_VERSION',  '2.3.1');
define('YCLP_DIR',      plugin_dir_path(__FILE__));
define('YCLP_URL',      plugin_dir_url(__FILE__));
define('YCLP_SLUG',     'yclp-admin');

// OTO consultation slots: 12 PM to 8 PM (9 slots)
define('YCLP_SLOTS', serialize([
    '12:00 PM', '1:00 PM', '2:00 PM', '3:00 PM',
    '4:00 PM',  '5:00 PM', '6:00 PM', '7:00 PM',
    '8:00 PM'
]));

// ── ACTIVATION ──
register_activation_hook(__FILE__, 'yclp_activate');
function yclp_activate() {
    yclp_create_tables();
    yclp_create_admin_page();
}

function yclp_create_tables() {
    global $wpdb;
    $charset = $wpdb->get_charset_collate();
    require_once(ABSPATH . 'wp-admin/includes/upgrade.php');

    // ── TABLE 1: Workshop Registrations (from landing page) ──
    $t_reg = $wpdb->prefix . 'yclp_registrations';
    dbDelta("CREATE TABLE IF NOT EXISTS $t_reg (
        id              BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        fname           VARCHAR(100),
        lname           VARCHAR(100),
        email           VARCHAR(200),
        phone           VARCHAR(20),
        standard        VARCHAR(50),
        city            VARCHAR(100),
        workshop_date   VARCHAR(100),
        package         VARCHAR(200),
        addon_book      VARCHAR(10)  DEFAULT 'No',
        addon_recording VARCHAR(10)  DEFAULT 'No',
        subtotal        DECIMAL(10,2) DEFAULT 0,
        gst             DECIMAL(10,2) DEFAULT 0,
        total           DECIMAL(10,2) DEFAULT 0,
        payment_id      VARCHAR(200),
        status          VARCHAR(100) DEFAULT 'Pending',
        created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;");

    // ── TABLE 2: OTO Consultation Bookings ──
    $t_oto = $wpdb->prefix . 'yclp_oto_bookings';
    dbDelta("CREATE TABLE IF NOT EXISTS $t_oto (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        fname        VARCHAR(100),
        lname        VARCHAR(100),
        email        VARCHAR(200),
        phone        VARCHAR(20),
        standard     VARCHAR(50),
        session_type VARCHAR(200),
        booking_date DATE,
        booking_time VARCHAR(20),
        payment_id   VARCHAR(200),
        total        DECIMAL(10,2),
        status       VARCHAR(50) DEFAULT 'Pending',
        created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
    ) $charset;");

    // ── TABLE 3: Booked slots (fast lookup for OTO) ──
    $t_slots = $wpdb->prefix . 'yclp_booked_slots';
    dbDelta("CREATE TABLE IF NOT EXISTS $t_slots (
        id           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        booking_date DATE NOT NULL,
        booking_time VARCHAR(20) NOT NULL,
        booking_id   BIGINT UNSIGNED,
        UNIQUE KEY date_time (booking_date, booking_time)
    ) $charset;");
}

// ── REST API ──
add_action('rest_api_init', function () {

    // ── WORKSHOP REGISTRATION (called from landing page) ──
    register_rest_route('yclp/v1', '/register', [
        'methods'             => 'POST',
        'callback'            => 'yclp_save_registration',
        'permission_callback' => '__return_true',
    ]);

    // ── OTO BOOKING (called from OTO page) ──
    register_rest_route('yclp/v1', '/oto-book', [
        'methods'             => 'POST',
        'callback'            => 'yclp_save_oto_booking',
        'permission_callback' => '__return_true',
    ]);

    // Get booked slots for a date
    register_rest_route('yclp/v1', '/booked-slots', [
        'methods'             => 'GET',
        'callback'            => 'yclp_get_booked_slots',
        'permission_callback' => '__return_true',
    ]);

    // Get slot names for calendar panel
    register_rest_route('yclp/v1', '/booked-slots-details', [
        'methods'             => 'GET',
        'callback'            => 'yclp_get_booked_slots_details',
        'permission_callback' => '__return_true',
    ]);

    // Get fully booked dates in a month
    register_rest_route('yclp/v1', '/booked-dates', [
        'methods'             => 'GET',
        'callback'            => 'yclp_get_booked_dates',
        'permission_callback' => '__return_true',
    ]);
});

// ── SAVE WORKSHOP REGISTRATION ──
function yclp_save_registration(WP_REST_Request $req) {
    global $wpdb;
    $d = $req->get_json_params();

    $table = $wpdb->prefix . 'yclp_registrations';

    $payment_id = sanitize_text_field($d['payment_id'] ?? '');
    $status     = sanitize_text_field($d['status']     ?? 'Pending');

    // Upsert: match by payment_id first.
    // If no payment_id yet (form submitted before payment), fall back to email+workshop_date
    // so the PAID update overwrites the "Form Submitted" row instead of creating a new one.
    $existing = null;
    if ($payment_id) {
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $table WHERE payment_id = %s", $payment_id
        ));
    }
    if (!$existing) {
        $email_check = sanitize_email($d['email'] ?? '');
        $date_check  = sanitize_text_field($d['workshop_date'] ?? '');
        if ($email_check && $date_check) {
            $existing = $wpdb->get_row($wpdb->prepare(
                "SELECT id FROM $table WHERE email = %s AND workshop_date = %s ORDER BY id DESC LIMIT 1",
                $email_check, $date_check
            ));
        }
    }

    $row = [
        'fname'           => sanitize_text_field($d['fname']           ?? ''),
        'lname'           => sanitize_text_field($d['lname']           ?? ''),
        'email'           => sanitize_email($d['email']                ?? ''),
        'phone'           => sanitize_text_field($d['phone']           ?? ''),
        'standard'        => sanitize_text_field($d['standard']        ?? ''),
        'city'            => sanitize_text_field($d['city']            ?? ''),
        'workshop_date'   => sanitize_text_field($d['workshop_date']   ?? ''),
        'package'         => sanitize_text_field($d['package']         ?? ''),
        'addon_book'      => sanitize_text_field($d['addon_book']      ?? 'No'),
        'addon_recording' => sanitize_text_field($d['addon_recording'] ?? 'No'),
        'subtotal'        => floatval($d['subtotal'] ?? 0),
        'gst'             => floatval($d['gst']      ?? 0),
        'total'           => floatval($d['total']    ?? 0),
        'payment_id'      => $payment_id,
        'status'          => $status,
    ];

    if ($existing) {
        $wpdb->update($table, $row, ['id' => $existing->id]);
        $id = $existing->id;
    } else {
        $wpdb->insert($table, $row);
        $id = $wpdb->insert_id;
    }

    return new WP_REST_Response(['success' => true, 'id' => $id], 200);
}

// ── SAVE OTO BOOKING ──
function yclp_save_oto_booking(WP_REST_Request $req) {
    global $wpdb;
    $d = $req->get_json_params();

    $booking_date = sanitize_text_field($d['date']       ?? '');
    $booking_time = sanitize_text_field($d['time']       ?? '');
    $payment_id   = sanitize_text_field($d['payment_id'] ?? '');
    $status       = sanitize_text_field($d['status']     ?? 'Pending');

    if (!$booking_date || !$booking_time) {
        return new WP_REST_Response(['error' => 'Date and time required'], 400);
    }

    // Minimum: tomorrow (calendar already blocks today)
    $min_allowed = date('Y-m-d', strtotime('+1 day'));
    if ($booking_date < $min_allowed) {
        return new WP_REST_Response(['error' => 'Bookings must be at least 1 day in advance'], 400);
    }

    $bookings = $wpdb->prefix . 'yclp_oto_bookings';
    $slots    = $wpdb->prefix . 'yclp_booked_slots';

    // If PAID — check slot not already taken
    if (strpos($status, 'PAID') !== false) {
        $exists = $wpdb->get_var($wpdb->prepare(
            "SELECT COUNT(*) FROM $slots WHERE booking_date = %s AND booking_time = %s",
            $booking_date, $booking_time
        ));
        if ($exists > 0) {
            return new WP_REST_Response(['error' => 'Slot already booked'], 409);
        }
    }

    // Upsert booking: match by payment_id first, then fall back to date+time+email
    // This handles the case where a pending row was saved with empty payment_id
    $existing = null;
    if ($payment_id) {
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $bookings WHERE payment_id = %s", $payment_id
        ));
    }
    if (!$existing && $booking_date && $booking_time) {
        $email_check = sanitize_email($d['email'] ?? '');
        $existing = $wpdb->get_row($wpdb->prepare(
            "SELECT id FROM $bookings WHERE booking_date = %s AND booking_time = %s AND email = %s ORDER BY id DESC LIMIT 1",
            $booking_date, $booking_time, $email_check
        ));
    }

    $row = [
        'fname'        => sanitize_text_field($d['fname']    ?? ''),
        'lname'        => sanitize_text_field($d['lname']    ?? ''),
        'email'        => sanitize_email($d['email']         ?? ''),
        'phone'        => sanitize_text_field($d['phone']    ?? ''),
        'standard'     => sanitize_text_field($d['standard'] ?? ''),
        'session_type' => sanitize_text_field($d['session']  ?? ''),
        'booking_date' => $booking_date,
        'booking_time' => $booking_time,
        'payment_id'   => $payment_id,
        'total'        => floatval($d['total'] ?? 0),
        'status'       => $status,
    ];

    if ($existing) {
        $wpdb->update($bookings, $row, ['id' => $existing->id]);
        $booking_id = $existing->id;
    } else {
        $wpdb->insert($bookings, $row);
        $booking_id = $wpdb->insert_id;
    }

    // Lock the slot once PAID
    if (strpos($status, 'PAID') !== false && $booking_id) {
        $wpdb->replace($slots, [
            'booking_date' => $booking_date,
            'booking_time' => $booking_time,
            'booking_id'   => $booking_id,
        ]);
    }

    return new WP_REST_Response(['success' => true, 'id' => $booking_id], 200);
}

function yclp_get_booked_slots(WP_REST_Request $req) {
    global $wpdb;
    $date = sanitize_text_field($req->get_param('date') ?? '');
    if (!$date) return new WP_REST_Response([], 200);
    $slots = $wpdb->prefix . 'yclp_booked_slots';
    $rows  = $wpdb->get_col($wpdb->prepare(
        "SELECT booking_time FROM $slots WHERE booking_date = %s", $date
    ));
    return new WP_REST_Response($rows, 200);
}

function yclp_get_booked_slots_details(WP_REST_Request $req) {
    global $wpdb;
    $date    = sanitize_text_field($req->get_param('date') ?? '');
    $t_slots = $wpdb->prefix . 'yclp_booked_slots';
    $t_books = $wpdb->prefix . 'yclp_oto_bookings';
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT s.booking_time, b.fname, b.lname
         FROM $t_slots s
         JOIN $t_books b ON s.booking_id = b.id
         WHERE s.booking_date = %s", $date
    ));
    $mapped = [];
    foreach ($results as $r) {
        $mapped[$r->booking_time] = trim($r->fname . ' ' . $r->lname);
    }
    return new WP_REST_Response($mapped, 200);
}

function yclp_get_booked_dates(WP_REST_Request $req) {
    global $wpdb;
    $year  = intval($req->get_param('year')  ?? date('Y'));
    $month = intval($req->get_param('month') ?? date('m'));
    $slots       = $wpdb->prefix . 'yclp_booked_slots';
    $total_slots = count(unserialize(YCLP_SLOTS));
    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT booking_date, COUNT(*) as cnt FROM $slots
         WHERE YEAR(booking_date) = %d AND MONTH(booking_date) = %d
         GROUP BY booking_date",
        $year, $month
    ));
    $fully_booked = [];
    $partial = [];
    foreach ($results as $r) {
        if (intval($r->cnt) >= $total_slots) $fully_booked[] = $r->booking_date;
        $partial[$r->booking_date] = intval($r->cnt);
    }
    return new WP_REST_Response([
        'fully_booked' => $fully_booked,
        'partial'      => $partial,
        'total_slots'  => $total_slots,
    ], 200);
}

// ── SHORTCODE ──
add_shortcode('yclp_admin_dashboard', 'yclp_render_dashboard');
function yclp_render_dashboard() {
    ob_start();
    include YCLP_DIR . 'templates/dashboard.php';
    return ob_get_clean();
}

// ── CREATE PAGE ──
function yclp_create_admin_page() {
    $existing = get_page_by_path(YCLP_SLUG);
    if (!$existing) {
        wp_insert_post([
            'post_title'   => 'YCLP Admin',
            'post_name'    => YCLP_SLUG,
            'post_status'  => 'publish',
            'post_type'    => 'page',
            'post_content' => '[yclp_admin_dashboard]',
        ]);
    }
}

// ── ENQUEUE ──
add_action('wp_enqueue_scripts', 'yclp_enqueue');
function yclp_enqueue() {
    if (!is_page(YCLP_SLUG)) return;
    wp_enqueue_style('yclp-css', YCLP_URL . 'assets/dashboard.css', [], YCLP_VERSION);
    wp_enqueue_script('yclp-js',  YCLP_URL . 'assets/dashboard.js',  [], YCLP_VERSION, true);
    wp_localize_script('yclp-js', 'YCLP', [
        'ajax'        => admin_url('admin-ajax.php'),
        'api'         => rest_url('yclp/v1/'),
        'nonce'       => wp_create_nonce('wp_rest'),
        'total_slots' => count(unserialize(YCLP_SLOTS)),
        'slots'       => unserialize(YCLP_SLOTS),
    ]);
}

// ── AUTH COOKIES ──
add_action('wp_ajax_nopriv_yclp_login', 'yclp_ajax_login');
function yclp_ajax_login() {
    $pw     = $_POST['password'] ?? '';
    $stored = get_option('yclp_admin_password', password_hash('Arctikk@2026', PASSWORD_DEFAULT));
    if (password_verify($pw, $stored)) {
        setcookie('yclp_admin', 'authenticated', time() + 8 * HOUR_IN_SECONDS, COOKIEPATH, COOKIE_DOMAIN, is_ssl(), true);
        wp_send_json_success('ok');
    } else {
        wp_send_json_error('Wrong password');
    }
}

add_action('wp_ajax_nopriv_yclp_logout', 'yclp_ajax_logout');
add_action('wp_ajax_yclp_logout',        'yclp_ajax_logout');
function yclp_ajax_logout() {
    setcookie('yclp_admin', '', time() - 3600, COOKIEPATH, COOKIE_DOMAIN);
    wp_send_json_success('logged out');
}

// ── AJAX: Get workshop registrations ──
add_action('wp_ajax_nopriv_yclp_get_registrations', 'yclp_get_registrations_ajax');
add_action('wp_ajax_yclp_get_registrations',        'yclp_get_registrations_ajax');
function yclp_get_registrations_ajax() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated')
        wp_send_json_error('Unauthorized', 401);

    global $wpdb;
    $table  = $wpdb->prefix . 'yclp_registrations';
    $search = sanitize_text_field($_GET['search'] ?? '');
    $status = sanitize_text_field($_GET['status'] ?? '');

    $where = 'WHERE 1=1';
    if ($search) $where .= $wpdb->prepare(
        ' AND (fname LIKE %s OR lname LIKE %s OR email LIKE %s OR phone LIKE %s OR city LIKE %s)',
        "%$search%", "%$search%", "%$search%", "%$search%", "%$search%"
    );
    if ($status) $where .= $wpdb->prepare(' AND status LIKE %s', "%$status%");

    $rows = $wpdb->get_results("SELECT * FROM $table $where ORDER BY created_at DESC");

    $stats = $wpdb->get_row("SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status LIKE '%PAID%' THEN 1 ELSE 0 END) as paid,
        SUM(CASE WHEN status LIKE '%PAID%' THEN total ELSE 0 END) as revenue,
        COUNT(DISTINCT CASE WHEN status LIKE '%PAID%' AND addon_book = 'Yes' THEN payment_id ELSE NULL END) as ebooks_sold
        FROM $table");

    wp_send_json_success(['registrations' => $rows, 'stats' => $stats]);
}

// ── AJAX: Export registrations CSV ──
add_action('wp_ajax_nopriv_yclp_export_reg_csv', 'yclp_export_reg_csv');
add_action('wp_ajax_yclp_export_reg_csv',        'yclp_export_reg_csv');
function yclp_export_reg_csv() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') die('Unauthorized');
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}yclp_registrations ORDER BY created_at DESC", ARRAY_A);
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="yclp-registrations-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    if (!empty($rows)) {
        fputcsv($out, array_keys($rows[0]));
        foreach ($rows as $row) fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

// ── AJAX: Get OTO bookings ──
add_action('wp_ajax_nopriv_yclp_get_bookings', 'yclp_get_bookings_ajax');
add_action('wp_ajax_yclp_get_bookings',        'yclp_get_bookings_ajax');
function yclp_get_bookings_ajax() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated')
        wp_send_json_error('Unauthorized', 401);

    global $wpdb;
    $table  = $wpdb->prefix . 'yclp_oto_bookings';
    $search = sanitize_text_field($_GET['search'] ?? '');
    $status = sanitize_text_field($_GET['status'] ?? '');
    $date   = sanitize_text_field($_GET['date']   ?? '');

    $where = 'WHERE 1=1';
    if ($search) $where .= $wpdb->prepare(' AND (fname LIKE %s OR lname LIKE %s OR email LIKE %s OR phone LIKE %s)',
        "%$search%", "%$search%", "%$search%", "%$search%");
    if ($status) $where .= $wpdb->prepare(' AND status = %s', $status);
    if ($date)   $where .= $wpdb->prepare(' AND booking_date = %s', $date);

    $bookings = $wpdb->get_results("SELECT * FROM $table $where ORDER BY booking_date ASC, booking_time ASC");
    $stats    = $wpdb->get_row("SELECT
        COUNT(*) as total,
        SUM(CASE WHEN status LIKE '%PAID%' THEN 1 ELSE 0 END) as paid,
        SUM(CASE WHEN status LIKE '%PAID%' THEN total ELSE 0 END) as revenue,
        COUNT(DISTINCT booking_date) as unique_dates
        FROM $table");

    wp_send_json_success(['bookings' => $bookings, 'stats' => $stats]);
}

// ── AJAX: Export OTO CSV ──
add_action('wp_ajax_nopriv_yclp_export_csv', 'yclp_export_csv');
add_action('wp_ajax_yclp_export_csv',        'yclp_export_csv');
function yclp_export_csv() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') die('Unauthorized');
    global $wpdb;
    $rows = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}yclp_oto_bookings ORDER BY booking_date ASC, booking_time ASC", ARRAY_A);
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="oto-bookings-' . date('Y-m-d') . '.csv"');
    $out = fopen('php://output', 'w');
    if (!empty($rows)) {
        fputcsv($out, array_keys($rows[0]));
        foreach ($rows as $row) fputcsv($out, $row);
    }
    fclose($out);
    exit;
}

// ── AJAX: Update status ──
add_action('wp_ajax_nopriv_yclp_update_status', 'yclp_update_status');
add_action('wp_ajax_yclp_update_status',        'yclp_update_status');
function yclp_update_status() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $id     = intval($_POST['id']);
    $status = sanitize_text_field($_POST['status']);
    $table  = sanitize_text_field($_POST['table'] ?? 'oto');
    $tname  = $table === 'reg'
        ? $wpdb->prefix . 'yclp_registrations'
        : $wpdb->prefix . 'yclp_oto_bookings';
    $wpdb->update($tname, ['status' => $status], ['id' => $id]);
    wp_send_json_success('updated');
}

// ── AJAX: Delete OTO booking ──
add_action('wp_ajax_nopriv_yclp_delete_booking', 'yclp_delete_booking');
add_action('wp_ajax_yclp_delete_booking',        'yclp_delete_booking');
function yclp_delete_booking() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $id = intval($_POST['id']);
    $booking = $wpdb->get_row($wpdb->prepare("SELECT booking_date, booking_time FROM {$wpdb->prefix}yclp_oto_bookings WHERE id = %d", $id));
    if ($booking) {
        $wpdb->delete($wpdb->prefix . 'yclp_booked_slots', [
            'booking_date' => $booking->booking_date,
            'booking_time' => $booking->booking_time,
        ]);
    }
    $wpdb->delete($wpdb->prefix . 'yclp_oto_bookings', ['id' => $id]);
    wp_send_json_success('deleted');
}

// ── AJAX: Delete registration ──
add_action('wp_ajax_nopriv_yclp_delete_registration', 'yclp_delete_registration');
add_action('wp_ajax_yclp_delete_registration',        'yclp_delete_registration');
function yclp_delete_registration() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $id = intval($_POST['id']);
    $wpdb->delete($wpdb->prefix . 'yclp_registrations', ['id' => $id]);
    wp_send_json_success('deleted');
}

// ── AJAX: Get OTO calendar ──
add_action('wp_ajax_nopriv_yclp_get_calendar', 'yclp_get_calendar_ajax');
add_action('wp_ajax_yclp_get_calendar',        'yclp_get_calendar_ajax');
function yclp_get_calendar_ajax() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $year  = intval($_GET['year']  ?? date('Y'));
    $month = intval($_GET['month'] ?? date('m'));

    $slots_table    = $wpdb->prefix . 'yclp_booked_slots';
    $bookings_table = $wpdb->prefix . 'yclp_oto_bookings';
    $total_slots    = count(unserialize(YCLP_SLOTS));

    $results = $wpdb->get_results($wpdb->prepare(
        "SELECT s.booking_date, s.booking_time, b.fname, b.lname, b.email, b.status
         FROM $slots_table s
         LEFT JOIN $bookings_table b ON s.booking_id = b.id
         WHERE YEAR(s.booking_date) = %d AND MONTH(s.booking_date) = %d
         ORDER BY s.booking_date, s.booking_time",
        $year, $month
    ));

    $calendar = [];
    foreach ($results as $r) {
        $calendar[$r->booking_date][] = [
            'time'   => $r->booking_time,
            'name'   => trim($r->fname . ' ' . $r->lname),
            'email'  => $r->email,
            'status' => $r->status,
        ];
    }

    wp_send_json_success(['calendar' => $calendar, 'total_slots' => $total_slots]);
}

// ── AJAX: Change password ──
add_action('wp_ajax_nopriv_yclp_change_password', 'yclp_change_password');
add_action('wp_ajax_yclp_change_password',        'yclp_change_password');
function yclp_change_password() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    $pw = sanitize_text_field($_POST['password'] ?? '');
    if (strlen($pw) < 6) wp_send_json_error('Too short');
    update_option('yclp_admin_password', password_hash($pw, PASSWORD_DEFAULT));
    wp_send_json_success('Password updated');
}

// ── AJAX: Reset all registrations ──
add_action('wp_ajax_nopriv_yclp_reset_registrations', 'yclp_reset_registrations');
add_action('wp_ajax_yclp_reset_registrations',        'yclp_reset_registrations');
function yclp_reset_registrations() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}yclp_registrations");
    wp_send_json_success('All registrations deleted');
}

// ── AJAX: Reset all OTO bookings ──
add_action('wp_ajax_nopriv_yclp_reset_bookings', 'yclp_reset_bookings');
add_action('wp_ajax_yclp_reset_bookings',        'yclp_reset_bookings');
function yclp_reset_bookings() {
    if (!isset($_COOKIE['yclp_admin']) || $_COOKIE['yclp_admin'] !== 'authenticated') wp_send_json_error('Unauthorized');
    global $wpdb;
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}yclp_oto_bookings");
    $wpdb->query("TRUNCATE TABLE {$wpdb->prefix}yclp_booked_slots");
    wp_send_json_success('All bookings and slots deleted');
}