// ═══════════════════════════════════════════════════════
//  ArctikkCircle — Google Apps Script
//  Handles BOTH YCLP Workshop registrations AND OTO Bookings
//  Deploy as Web App → Anyone can access
// ═══════════════════════════════════════════════════════

function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    const ss   = SpreadsheetApp.getActiveSpreadsheet();

    // Route to correct sheet based on type
    if (data.sheet_tab === 'OTO Bookings' || data.type === 'OTO_CONSULTATION') {
      saveOTOBooking(ss, data);
    } else {
      saveWorkshopRegistration(ss, data);
    }

    return ContentService
      .createTextOutput(JSON.stringify({ success: true }))
      .setMimeType(ContentService.MimeType.JSON);

  } catch (err) {
    return ContentService
      .createTextOutput(JSON.stringify({ success: false, error: err.message }))
      .setMimeType(ContentService.MimeType.JSON);
  }
}

// ════════════════════════════════════════════
//  SHEET 1: YCLP Workshop Registrations
// ════════════════════════════════════════════
function saveWorkshopRegistration(ss, data) {
  const sheetName = 'Workshop Registrations';
  let sheet = ss.getSheetByName(sheetName);

  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    // Header row
    sheet.appendRow([
      'Timestamp', 'First Name', 'Last Name', 'Email', 'Phone',
      'City', 'Standard', 'Workshop Date', 'Package',
      'Addon Book', 'Addon Recording',
      'Subtotal (₹)', 'GST (₹)', 'Total (₹)',
      'Payment ID', 'Status'
    ]);
    // Style header
    styleHeader(sheet, 1, 16);
  }

  sheet.appendRow([
    data.timestamp     || new Date().toLocaleString('en-IN'),
    data.fname         || '',
    data.lname         || '',
    data.email         || '',
    data.phone         || '',
    data.city          || '',
    data.standard      || '',
    data.workshop_date || '',
    data.package       || '',
    data.addon_book    || 'No',
    data.addon_recording || 'No',
    Number(data.subtotal) || 0,
    Number(data.gst)      || 0,
    Number(data.total)    || 0,
    data.payment_id    || '',
    data.status        || 'Pending',
  ]);

  // Colour the status cell
  colorStatusCell(sheet, 16);
}

// ════════════════════════════════════════════
//  SHEET 2: OTO Consultation Bookings
// ════════════════════════════════════════════
function saveOTOBooking(ss, data) {
  const sheetName = 'OTO Bookings';
  let sheet = ss.getSheetByName(sheetName);

  if (!sheet) {
    sheet = ss.insertSheet(sheetName);
    // Header row — includes Date and Time columns
    sheet.appendRow([
      'Booked On',
      'First Name', 'Last Name', 'Email', 'Phone',
      'Child Standard',
      'Session Type',
      '📅 Appointment Date',
      '⏰ Appointment Time',
      'Total (₹)',
      'Payment ID',
      'Status',
      'Workshop',
    ]);
    styleHeader(sheet, 1, 13);

    // Set column widths for readability
    sheet.setColumnWidth(8, 160);  // Date
    sheet.setColumnWidth(9, 130);  // Time
    sheet.setColumnWidth(7, 200);  // Session type
    sheet.setColumnWidth(3, 200);  // Email
  }

  sheet.appendRow([
    data.timestamp   || new Date().toLocaleString('en-IN'),
    data.fname       || '',
    data.lname       || '',
    data.email       || '',
    data.phone       || '',
    data.standard    || '',
    data.session     || '',
    data.date        || '',     // ISO date YYYY-MM-DD
    data.time        || '',     // e.g. "3:00 PM"
    Number(data.total) || 1179,
    data.payment_id  || '',
    data.status      || 'Pending',
    data.workshop    || 'YCLP Workshop',
  ]);

  // Colour the status cell (col 12)
  colorStatusCell(sheet, 12);

  // If PAID — highlight the row green
  if (data.status && data.status.includes('PAID')) {
    const lastRow = sheet.getLastRow();
    sheet.getRange(lastRow, 1, 1, 13)
      .setBackground('#e6f4ea');
  }
}

// ════════════════════════════════════════════
//  HELPERS
// ════════════════════════════════════════════
function styleHeader(sheet, row, cols) {
  const range = sheet.getRange(row, 1, 1, cols);
  range.setBackground('#0f0f0f')
       .setFontColor('#ffffff')
       .setFontWeight('bold')
       .setFontSize(10);
  sheet.setFrozenRows(1);
}

function colorStatusCell(sheet, statusCol) {
  const lastRow  = sheet.getLastRow();
  const cell     = sheet.getRange(lastRow, statusCol);
  const statusVal= cell.getValue() || '';

  if (statusVal.includes('PAID')) {
    cell.setBackground('#16a34a').setFontColor('#ffffff').setFontWeight('bold');
  } else if (statusVal.includes('Cancelled')) {
    cell.setBackground('#c93535').setFontColor('#ffffff').setFontWeight('bold');
  } else if (statusVal.includes('Abandoned')) {
    cell.setBackground('#ea580c').setFontColor('#ffffff').setFontWeight('bold');
  } else {
    cell.setBackground('#fef9c3').setFontColor('#854d0e');
  }
}

// ── GET endpoint (optional — for testing) ──
function doGet(e) {
  return ContentService
    .createTextOutput('ArctikkCircle Google Sheets API — Active ✅')
    .setMimeType(ContentService.MimeType.TEXT);
}
