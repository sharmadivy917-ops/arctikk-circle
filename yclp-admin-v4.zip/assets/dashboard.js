(function () {
  'use strict';

  const ajax        = YCLP.ajax;
  const api         = YCLP.api;
  const ALL_SLOTS   = YCLP.slots;
  const TOTAL_SLOTS = YCLP.total_slots;

  let allRegistrations  = [];
  let allBookings       = [];
  let calYear, calMonth;
  let refreshTimer      = null;
  let pendingManualDate = '';
  let pendingManualTime = '';
  let statusModalId     = null;
  let statusModalTable  = 'oto';

  const MONTHS = ['January','February','March','April','May','June',
                  'July','August','September','October','November','December'];

  /* ══════════════════════════════════════════════
     INIT
  ══════════════════════════════════════════════ */
  document.addEventListener('DOMContentLoaded', function () {
    checkAuth();

    // API endpoint display
    setText('yclp-api-reg',   api + 'register');
    setText('yclp-api-book',  api + 'oto-book');
    setText('yclp-api-slots', api + 'booked-slots?date=YYYY-MM-DD');
    setText('yclp-api-dates', api + 'booked-dates?year=YYYY&month=MM');
    setText('info-total-slots', TOTAL_SLOTS);

    // Slots preview
    const sp = document.getElementById('slots-preview');
    if (sp && ALL_SLOTS) {
      sp.innerHTML = ALL_SLOTS.map(s =>
        `<span style="background:#242424;border:1px solid #2e2e2e;border-radius:6px;padding:5px 12px;font-size:.8rem;color:#e8b84b;">${s}</span>`
      ).join('');
    }

    // Bind buttons
    bindClick('yclp-login-btn',  doLogin);
    bindClick('yclp-logout-btn', doLogout);
    bindClick('reg-refresh-btn', loadRegistrations);
    bindClick('reg-export-btn',  exportRegCSV);
    bindClick('yclp-refresh-btn', loadBookings);
    bindClick('yclp-export-btn',  exportCSV);

    // Enter on password
    const passEl = document.getElementById('yclp-pass');
    if (passEl) passEl.addEventListener('keydown', e => { if (e.key === 'Enter') doLogin(); });

    // Tabs
    document.querySelectorAll('.yclp-tab-btn').forEach(btn => {
      btn.addEventListener('click', () => switchTab(btn.dataset.tab, btn));
    });

    // Filters — registrations
    bindInput('reg-search',          () => applyRegFilters());
    bindChange('reg-filter-status',  () => applyRegFilters());

    // Filters — OTO bookings
    bindInput('yclp-search',         () => applyFilters());
    bindChange('yclp-filter-status', () => applyFilters());
    bindChange('yclp-filter-date',   () => applyFilters());

    // Calendar nav
    bindClick('cal-prev', () => { calMonth--; if (calMonth < 0) { calMonth = 11; calYear--; } loadAdminCalendar(); });
    bindClick('cal-next', () => { calMonth++; if (calMonth > 11) { calMonth = 0; calYear++; } loadAdminCalendar(); });
  });

  /* ══════════════════════════════════════════════
     AUTH
  ══════════════════════════════════════════════ */
  function checkAuth() {
    getCookie('yclp_admin') === 'authenticated' ? showDashboard() : showLogin();
  }

  function showLogin() {
    show('yclp-login', 'flex');
    hide('yclp-dashboard');
  }

  function showDashboard() {
    hide('yclp-login');
    show('yclp-dashboard', 'block');
    loadRegistrations();
    loadBookings();
    const now = new Date();
    calYear  = now.getFullYear();
    calMonth = now.getMonth();
    if (refreshTimer) clearInterval(refreshTimer);
    refreshTimer = setInterval(() => { loadRegistrations(); loadBookings(); }, 60000);
  }

  function doLogin() {
    const pass = val('yclp-pass');
    const err  = document.getElementById('yclp-login-err');
    const btn  = document.getElementById('yclp-login-btn');
    if (!pass) { showEl(err, 'Enter password.'); return; }
    btn.textContent = 'Logging in…'; btn.disabled = true;
    postAjax('yclp_login', { password: pass }, res => {
      btn.textContent = 'Login →'; btn.disabled = false;
      if (res.success) { hideEl(err); showDashboard(); }
      else showEl(err, 'Wrong password. Try again.');
    });
  }

  function doLogout() {
    if (refreshTimer) clearInterval(refreshTimer);
    postAjax('yclp_logout', {}, () => {
      document.cookie = 'yclp_admin=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;';
      showLogin();
    });
  }

  /* ══════════════════════════════════════════════
     WORKSHOP REGISTRATIONS
  ══════════════════════════════════════════════ */
  function loadRegistrations() {
    const params = new URLSearchParams({ action: 'yclp_get_registrations' });
    fetch(ajax + '?' + params)
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          allRegistrations = res.data.registrations || [];
          const s = res.data.stats || {};
          setText('stat-reg-total',   s.total   || 0);
          setText('stat-reg-paid',    s.paid    || 0);
          setText('stat-reg-revenue', s.revenue ? '₹' + Number(s.revenue).toLocaleString('en-IN') : '₹0');
          applyRegFilters();
          renderRevenue(allRegistrations);
        }
      })
      .catch(err => console.error('Load registrations error:', err));
  }

  function applyRegFilters() {
    const search = (val('reg-search') || '').toLowerCase();
    const status = val('reg-filter-status') || '';

    const filtered = allRegistrations.filter(r => {
      const fullName = ((r.fname || '') + ' ' + (r.lname || '')).toLowerCase();
      const matchSearch = !search ||
        fullName.includes(search) ||
        (r.email || '').toLowerCase().includes(search) ||
        (r.phone || '').includes(search) ||
        (r.city  || '').toLowerCase().includes(search);
      const matchStatus = !status || (r.status || '').includes(status);
      return matchSearch && matchStatus;
    });

    renderRegistrations(filtered);
  }

  function renderRegistrations(regs) {
    const tbody = document.getElementById('yclp-reg-body');
    const count = document.getElementById('reg-count');
    if (!tbody) return;

    if (count) count.textContent = `Showing ${regs.length} registration${regs.length !== 1 ? 's' : ''}`;

    if (!regs.length) {
      tbody.innerHTML = '<tr><td colspan="14" class="yclp-loading">No registrations found.</td></tr>';
      return;
    }

    // Bind select-all for registrations
    const regSelectAll = document.getElementById('reg-select-all');
    if (regSelectAll) {
      regSelectAll.checked = false;
      regSelectAll.onchange = function() {
        document.querySelectorAll('.reg-row-cb').forEach(cb => cb.checked = this.checked);
        updateRegBulkBtn();
      };
    }

    tbody.innerHTML = regs.map((r, i) => {
      const badgeCls = (r.status || '').includes('PAID')
        ? 'badge-paid'
        : (r.status || '').includes('Cancelled') || (r.status || '').includes('Abandoned')
          ? 'badge-cancel' : 'badge-pending';

      const amount = r.total && parseFloat(r.total) > 0
        ? '₹' + parseFloat(r.total).toLocaleString('en-IN') : '—';

      const payId = r.payment_id
        ? `<span title="${esc(r.payment_id)}" style="font-size:.72rem;color:#888;cursor:help;">${esc(r.payment_id).slice(0,14)}…</span>`
        : '—';

      const ebook = r.addon_book === 'Yes'
        ? '<span style="color:#16a34a;font-weight:700;">✅ Yes</span>'
        : '<span style="color:#888;">—</span>';

      const createdAt = r.created_at
        ? new Date(r.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })
        : '—';

      return `<tr>
        <td><input type="checkbox" class="reg-row-cb" data-id="${r.id}" onchange="updateRegBulkBtn()"></td>
        <td>${i + 1}</td>
        <td style="font-weight:600;">${esc(r.fname)} ${esc(r.lname)}</td>
        <td>${esc(r.phone) || '—'}</td>
        <td style="font-size:.8rem;">${esc(r.email) || '—'}</td>
        <td>${esc(r.standard) || '—'}</td>
        <td>${esc(r.city) || '—'}</td>
        <td style="font-size:.82rem;font-weight:600;">${esc(r.workshop_date) || '—'}</td>
        <td style="font-size:.76rem;color:#888;">${esc(r.package) || '—'}</td>
        <td style="text-align:center;">${ebook}</td>
        <td style="font-weight:700;">${amount}</td>
        <td><span class="yclp-badge ${badgeCls}">${esc(r.status) || '—'}</span></td>
        <td>${payId}</td>
        <td style="font-size:.78rem;color:#888;">${createdAt}</td>
        <td>
          <button class="yclp-action-btn action-status" onclick="openStatusModal(${r.id},'${esc(r.status)}','reg')">✏️</button>
          <button class="yclp-action-btn action-delete" onclick="deleteRegistration(${r.id})">🗑</button>
        </td>
      </tr>`;
    }).join('');
  }

  function exportRegCSV() {
    window.location.href = ajax + '?action=yclp_export_reg_csv';
  }

  window.deleteRegistration = function (id) {
    if (!confirm('Delete this registration?')) return;
    const fd = new FormData();
    fd.append('action', 'yclp_delete_registration');
    fd.append('id', id);
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => { if (res.success) loadRegistrations(); else alert('Error deleting'); });
  };

  /* ══════════════════════════════════════════════
     OTO BOOKINGS
  ══════════════════════════════════════════════ */
  function loadBookings() {
    const params = new URLSearchParams({ action: 'yclp_get_bookings' });
    fetch(ajax + '?' + params)
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          allBookings = res.data.bookings || [];
          const s = res.data.stats || {};
          setText('stat-oto-paid', s.paid || 0);
          applyFilters();
        }
      })
      .catch(err => console.error('Load bookings error:', err));
  }

  function applyFilters() {
    const search = (val('yclp-search') || '').toLowerCase();
    const status = val('yclp-filter-status') || '';
    const date   = val('yclp-filter-date')   || '';

    const filtered = allBookings.filter(b => {
      const fullName = ((b.fname || '') + ' ' + (b.lname || '')).toLowerCase();
      const matchSearch = !search ||
        fullName.includes(search) ||
        (b.email || '').toLowerCase().includes(search) ||
        (b.phone || '').includes(search);
      const matchStatus = !status || (b.status || '') === status;
      const matchDate   = !date   || (b.booking_date || '') === date;
      return matchSearch && matchStatus && matchDate;
    });

    renderBookings(filtered);
  }

  function renderBookings(bookings) {
    const tbody = document.getElementById('yclp-bookings-body');
    const count = document.getElementById('yclp-count');
    if (!tbody) return;

    if (count) count.textContent = `Showing ${bookings.length} booking${bookings.length !== 1 ? 's' : ''}`;

    if (!bookings.length) {
      tbody.innerHTML = '<tr><td colspan="12" class="yclp-loading">No bookings found.</td></tr>';
      return;
    }

    // Bind select-all for OTO
    const otoSelectAll = document.getElementById('oto-select-all');
    if (otoSelectAll) {
      otoSelectAll.checked = false;
      otoSelectAll.onchange = function() {
        document.querySelectorAll('.oto-row-cb').forEach(cb => cb.checked = this.checked);
        updateOtoBulkBtn();
      };
    }

    tbody.innerHTML = bookings.map((b, i) => {
      const badgeCls = (b.status || '').includes('PAID')      ? 'badge-paid'
                     : (b.status || '').includes('Cancelled') ? 'badge-cancel'
                     : (b.status || '').includes('Skipped')   ? 'badge-cancel'
                     : 'badge-pending';

      const amount = b.total && parseFloat(b.total) > 0
        ? '₹' + parseFloat(b.total).toLocaleString('en-IN') : '—';

      const payId = b.payment_id
        ? `<span title="${esc(b.payment_id)}" style="font-size:.72rem;color:#888;cursor:help;">${esc(b.payment_id).slice(0,14)}…</span>`
        : '—';

      const createdAt = b.created_at
        ? new Date(b.created_at).toLocaleDateString('en-IN', { day:'2-digit', month:'short', year:'numeric' })
        : '—';

      return `<tr>
        <td><input type="checkbox" class="oto-row-cb" data-id="${b.id}" onchange="updateOtoBulkBtn()"></td>
        <td>${i + 1}</td>
        <td style="font-weight:600;">${esc(b.fname)} ${esc(b.lname)}</td>
        <td>${esc(b.phone) || '—'}</td>
        <td style="font-size:.8rem;">${esc(b.email) || '—'}</td>
        <td>${esc(b.standard) || '—'}</td>
        <td><div class="dt-cell"><span class="dt-date">${b.booking_date || '—'}</span></div></td>
        <td><span class="dt-time">${esc(b.booking_time) || '—'}</span></td>
        <td style="font-weight:700;">${amount}</td>
        <td><span class="yclp-badge ${badgeCls}">${esc(b.status) || '—'}</span></td>
        <td>${payId}</td>
        <td style="font-size:.78rem;color:#888;">${createdAt}</td>
        <td>
          <button class="yclp-action-btn action-status" onclick="openStatusModal(${b.id},'${esc(b.status)}','oto')">✏️</button>
          <button class="yclp-action-btn action-delete" onclick="deleteBooking(${b.id})">🗑</button>
        </td>
      </tr>`;
    }).join('');
  }

  function exportCSV() {
    window.location.href = ajax + '?action=yclp_export_csv';
  }

  window.deleteBooking = function (id) {
    if (!confirm('Delete this OTO booking? This will free the slot.')) return;
    const fd = new FormData();
    fd.append('action', 'yclp_delete_booking');
    fd.append('id', id);
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => {
        if (res.success) { loadBookings(); loadAdminCalendar(); }
        else alert('Error deleting booking');
      });
  };

  /* ══════════════════════════════════════════════
     STATUS MODAL — shared for both tables
  ══════════════════════════════════════════════ */
  const REG_STATUSES = [
    'PAID ✅', 'Form Submitted — Payment Pending',
    'Payment Abandoned ⚠️', 'Payment Cancelled ❌'
  ];
  const OTO_STATUSES = [
    'OTO PAID ✅', 'OTO — Payment Pending',
    'OTO Cancelled ❌', 'OTO Skipped 🚫'
  ];

  window.openStatusModal = function (id, currentStatus, table) {
    statusModalId    = id;
    statusModalTable = table || 'oto';
    setText('status-modal-id', '#' + id);
    const hiddenTable = document.getElementById('status-modal-table');
    if (hiddenTable) hiddenTable.value = statusModalTable;
    const sel = document.getElementById('status-modal-select');
    if (sel) {
      const opts = statusModalTable === 'reg' ? REG_STATUSES : OTO_STATUSES;
      sel.innerHTML = opts.map(o =>
        `<option value="${esc(o)}"${o === currentStatus ? ' selected' : ''}>${esc(o)}</option>`
      ).join('');
    }
    show('status-modal', 'flex');
  };

  window.closeStatusModal = function () {
    hide('status-modal');
    statusModalId = null;
  };

  window.confirmStatusUpdate = function () {
    if (!statusModalId) return;
    const status = val('status-modal-select');
    const table  = val('status-modal-table') || statusModalTable;
    const fd = new FormData();
    fd.append('action', 'yclp_update_status');
    fd.append('id', statusModalId);
    fd.append('status', status);
    fd.append('table', table);
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          closeStatusModal();
          if (table === 'reg') loadRegistrations(); else loadBookings();
        } else {
          alert('Error updating status');
        }
      });
  };

  /* ══════════════════════════════════════════════
     ADMIN CALENDAR
  ══════════════════════════════════════════════ */
  function loadAdminCalendar() {
    const label = document.getElementById('cal-month-label');
    if (label) label.textContent = MONTHS[calMonth] + ' ' + calYear;
    const params = new URLSearchParams({ action: 'yclp_get_calendar', year: calYear, month: calMonth + 1 });
    fetch(ajax + '?' + params)
      .then(r => r.json())
      .then(res => {
        if (res.success) renderAdminCalendar(res.data.calendar || {}, res.data.total_slots || TOTAL_SLOTS);
      })
      .catch(err => console.error('Calendar load error:', err));
  }

  function renderAdminCalendar(calData, totalSlots) {
    const grid = document.getElementById('adminCalDays');
    if (!grid) return;
    const today    = new Date(); today.setHours(0,0,0,0);
    const firstDay = new Date(calYear, calMonth, 1).getDay();
    const daysInMon = new Date(calYear, calMonth + 1, 0).getDate();
    let html = '';
    for (let i = 0; i < firstDay; i++) html += '<div class="admin-cal-day empty"></div>';
    for (let d = 1; d <= daysInMon; d++) {
      const iso   = calYear + '-' + String(calMonth+1).padStart(2,'0') + '-' + String(d).padStart(2,'0');
      const dt    = new Date(calYear, calMonth, d);
      const slots = (calData[iso] || []).length;
      const isToday = dt.getTime() === today.getTime();
      let cls = 'admin-cal-day';
      if (isToday)                        cls += ' today';
      if (slots >= totalSlots && slots>0) cls += ' fully-booked';
      else if (slots > 0)                 cls += ' partial';
      const dot = slots > 0 ? '<span class="cal-dot"></span>' : '';
      html += `<div class="${cls}" onclick="window.showDaySlots('${iso}','${d} ${MONTHS[calMonth]} ${calYear}',${slots},${totalSlots})">
        <span>${d}</span>
        <span class="cal-count">${slots}/${totalSlots}</span>
        ${dot}
      </div>`;
    }
    grid.innerHTML = html;
  }

  window.showDaySlots = function (iso, label, slotCount, totalSlots) {
    hide('slotPanelEmpty');
    show('slotPanelContent', 'block');
    hide('entryInfoTable');
    setText('slotDetailDate',    label);
    setText('slotDetailSummary', slotCount + ' of ' + totalSlots + ' slots booked');
    const grid = document.getElementById('slotGridAdmin');
    if (grid) grid.innerHTML = '<div style="color:#888;font-size:.82rem;text-align:center;padding:16px;">Loading…</div>';
    fetch(api + 'booked-slots-details?date=' + iso)
      .then(r => r.json())
      .then(bookedData => {
        if (!grid) return;
        grid.innerHTML = ALL_SLOTS.map(slot => {
          const name     = bookedData[slot] || '';
          const isBooked = name !== '';
          const cls      = isBooked ? 'slot-admin-item booked' : 'slot-admin-item available';
          const action   = isBooked
            ? `window.viewEntryDetails('${iso}','${slot}')`
            : `window.openManualBooking('${iso}','${slot}')`;
          return `<div class="${cls}" onclick="${action}" style="cursor:pointer;">
            <div class="slot-time">${slot}</div>
            <div class="${isBooked ? 'slot-name' : 'slot-free'}">${isBooked ? '👤 ' + esc(name) : '+ Add'}</div>
          </div>`;
        }).join('');
      })
      .catch(() => { if (grid) grid.innerHTML = '<div style="color:#c93535;font-size:.82rem;text-align:center;padding:16px;">Failed to load.</div>'; });
  };

  window.viewEntryDetails = function (date, time) {
    const entry = allBookings.find(b => b.booking_date === date && b.booking_time === time);
    const panel = document.getElementById('entryInfoTable');
    if (!panel) return;
    panel.style.display = 'block';
    if (entry) {
      setText('det-name',    (entry.fname||'') + ' ' + (entry.lname||''));
      setText('det-phone',   entry.phone    || '—');
      setText('det-email',   entry.email    || '—');
      setText('det-std',     entry.standard || '—');
      setText('det-payment', entry.payment_id || '—');
      const st = document.getElementById('det-status');
      if (st) { st.textContent = entry.status || '—'; st.style.color = (entry.status||'').includes('PAID') ? '#16a34a' : (entry.status||'').includes('Pending') ? '#e8b84b' : '#c93535'; }
    } else {
      setText('det-name','—'); setText('det-phone','—'); setText('det-email','—');
      setText('det-std','—'); setText('det-payment','—');
    }
  };

  /* ══════════════════════════════════════════════
     MANUAL OTO BOOKING
  ══════════════════════════════════════════════ */
  window.openManualBooking = function (d, t) {
    pendingManualDate = d;
    pendingManualTime = t;
    const info = document.getElementById('mb-slot-info');
    if (info) {
      info.textContent  = '📅 ' + d + ' at ' + t;
      info.style.display = 'block';
    }
    ['mb-fname','mb-lname','mb-email','mb-phone','mb-standard'].forEach(id => {
      const el = document.getElementById(id); if (el) el.value = '';
    });
    show('manual-booking-modal', 'flex');
  };

  window.closeManualBooking = function () { hide('manual-booking-modal'); };

  window.submitManualBooking = function () {
    const data = {
      fname: val('mb-fname'), lname: val('mb-lname'),
      email: val('mb-email'), phone: val('mb-phone'),
      standard: val('mb-standard'),
      date: pendingManualDate, time: pendingManualTime,
      status: 'OTO PAID ✅', total: 999,
      session: 'Manual Admin Entry', type: 'OTO_CONSULTATION',
    };
    if (!data.fname || !data.email) { alert('First Name and Email required.'); return; }
    const btn = document.getElementById('mb-save-btn');
    if (btn) { btn.textContent = 'Saving…'; btn.disabled = true; }
    fetch(api + 'oto-book', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data)
    })
      .then(r => r.json())
      .then(res => {
        if (res.success) {
          alert('Booking added ✅');
          window.closeManualBooking();
          loadBookings();
          loadAdminCalendar();
          window.showDaySlots(pendingManualDate, pendingManualDate, 0, TOTAL_SLOTS);
        } else {
          alert('Error: ' + (res.data?.error || 'Slot may already be taken.'));
        }
      })
      .catch(err => alert('Network error: ' + err))
      .finally(() => { if (btn) { btn.textContent = 'Save Booking ✅'; btn.disabled = false; } });
  };

  /* ══════════════════════════════════════════════
     REVENUE TAB
  ══════════════════════════════════════════════ */
  function renderRevenue(registrations) {
    const paid    = registrations.filter(r => (r.status||'').includes('PAID'));
    const pending = registrations.filter(r => (r.status||'').includes('Pending') || (r.status||'').includes('Abandoned'));
    const ebooks  = registrations.filter(r => r.addon_book === 'Yes' && (r.status||'').includes('PAID')).length;
    const revenue = paid.reduce((sum, r) => sum + parseFloat(r.total||0), 0);

    setText('rev-total-revenue', '₹' + revenue.toLocaleString('en-IN'));
    setText('rev-paid-count',    paid.length);
    setText('rev-pending-count', pending.length);
    setText('rev-ebook-count',   ebooks);

    // Funnel
    const total = registrations.length;
    const funnel = [
      { label: 'Total Form Submissions',   count: total,         color: '#2563eb' },
      { label: 'Reached Payment (Initiated)', count: total - pending.length, color: '#e8b84b' },
      { label: 'Completed Payment (Paid)', count: paid.length,   color: '#16a34a' },
    ];
    const breakdown = document.getElementById('yclp-session-breakdown');
    if (breakdown) {
      breakdown.innerHTML = funnel.map(f => {
        const pct = total > 0 ? Math.round((f.count / total) * 100) : 0;
        return `<div class="session-row">
          <span class="session-name">${f.label}</span>
          <div class="session-bar-wrap"><div class="session-bar" style="width:${pct}%;background:${f.color};"></div></div>
          <span class="session-count" style="color:${f.color};">${f.count} (${pct}%)</span>
        </div>`;
      }).join('');
    }

    // Recent paid table
    const revBody = document.getElementById('yclp-rev-body');
    if (revBody) {
      if (!paid.length) {
        revBody.innerHTML = '<tr><td colspan="6" style="text-align:center;padding:30px;color:#888;">No paid registrations yet.</td></tr>';
      } else {
        revBody.innerHTML = paid.slice(0, 20).map(r => `<tr>
          <td style="padding:10px 14px;font-weight:600;">${esc(r.fname)} ${esc(r.lname)}</td>
          <td style="padding:10px 14px;">${esc(r.phone||'—')}</td>
          <td style="padding:10px 14px;">${esc(r.city||'—')}</td>
          <td style="padding:10px 14px;font-size:.8rem;">${esc(r.package||'—')}</td>
          <td style="padding:10px 14px;font-weight:700;color:#16a34a;">₹${parseFloat(r.total||0).toLocaleString('en-IN')}</td>
          <td style="padding:10px 14px;font-size:.72rem;color:#888;">${esc(r.payment_id||'—')}</td>
        </tr>`).join('');
      }
    }
  }

  /* ══════════════════════════════════════════════
     SETTINGS — CHANGE PASSWORD
  ══════════════════════════════════════════════ */
  window.changePassword = function () {
    const p1  = val('new-pass-1');
    const p2  = val('new-pass-2');
    const msg = document.getElementById('pw-msg');
    if (!p1 || p1.length < 6) { showEl(msg, '⚠️ Password must be at least 6 characters.', '#ea580c'); return; }
    if (p1 !== p2)            { showEl(msg, '⚠️ Passwords do not match.', '#ea580c'); return; }
    const fd = new FormData();
    fd.append('action', 'yclp_change_password');
    fd.append('password', p1);
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => {
        if (res.success) showEl(msg, '✅ Password updated!', '#16a34a');
        else             showEl(msg, '❌ Error: ' + (res.data || 'Unknown'), '#c93535');
      });
  };

  /* ══════════════════════════════════════════════
     TAB SWITCHING
  ══════════════════════════════════════════════ */
  function switchTab(tab, btn) {
    document.querySelectorAll('.yclp-tab-content').forEach(el => el.style.display = 'none');
    document.querySelectorAll('.yclp-tab-btn').forEach(el => el.classList.remove('active'));
    const target = document.getElementById('tab-' + tab);
    if (target) target.style.display = 'block';
    if (btn) btn.classList.add('active');
    if (tab === 'calendar') loadAdminCalendar();
    if (tab === 'landingpage') {
      const iframe = document.getElementById('lp-iframe');
      if (iframe && iframe.src === 'about:blank') {
        iframe.src = iframe.getAttribute('data-src') || 'https://arctikkcircle.in/';
      }
    }
  }

  /* ══════════════════════════════════════════════
     LANDING PAGE DEVICE TOGGLE
  ══════════════════════════════════════════════ */
  window.yclpSetLPWidth = function (width, key) {
    const iframe = document.getElementById('lp-iframe');
    if (iframe) iframe.style.width = width;
    const map = { desktop: 'lp-btn-desktop', tablet: 'lp-btn-tablet', mobile: 'lp-btn-mobile' };
    document.querySelectorAll('.lp-device-btn').forEach(b => {
      b.classList.remove('lp-active');
    });
    const activeBtn = document.getElementById(map[key]);
    if (activeBtn) activeBtn.classList.add('lp-active');
  };

  /* ══════════════════════════════════════════════
     HELPERS
  ══════════════════════════════════════════════ */
  function postAjax(action, data, cb) {
    const fd = new FormData();
    fd.append('action', action);
    Object.entries(data).forEach(([k, v]) => fd.append(k, v));
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json()).then(cb)
      .catch(err => console.error('Ajax error:', err));
  }

  function getCookie(n) {
    return document.cookie.split('; ').reduce((r, c) => {
      const [k, v] = c.split('='); return k === n ? decodeURIComponent(v) : r;
    }, '');
  }

  function esc(s) {
    return String(s || '')
      .replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  function val(id)        { const el = document.getElementById(id); return el ? el.value : ''; }
  function setText(id, t) { const el = document.getElementById(id); if (el) el.textContent = t; }
  function show(id, d)    { const el = document.getElementById(id); if (el) el.style.display = d || 'block'; }
  function hide(id)       { const el = document.getElementById(id); if (el) el.style.display = 'none'; }
  function bindClick(id, fn)   { const el = document.getElementById(id); if (el) el.addEventListener('click', fn); }
  function bindInput(id, fn)   { const el = document.getElementById(id); if (el) el.addEventListener('input', fn); }
  function bindChange(id, fn)  { const el = document.getElementById(id); if (el) el.addEventListener('change', fn); }
  function showEl(el, msg, color) { if (!el) return; el.textContent = msg; el.style.display = 'block'; el.style.color = color || '#ff6b6b'; }
  function hideEl(el) { if (el) el.style.display = 'none'; }

  window.toggleSidebar = function () {};

  /* ══════════════════════════════════════════════
     BULK DELETE & RESET
  ══════════════════════════════════════════════ */
  function updateRegBulkBtn() {
    const checked = document.querySelectorAll('.reg-row-cb:checked').length;
    const btn = document.getElementById('reg-bulk-delete-btn');
    if (btn) {
      btn.style.display = checked > 0 ? 'inline-flex' : 'none';
      btn.textContent = '🗑 Delete Selected (' + checked + ')';
    }
  }

  function updateOtoBulkBtn() {
    const checked = document.querySelectorAll('.oto-row-cb:checked').length;
    const btn = document.getElementById('oto-bulk-delete-btn');
    if (btn) {
      btn.style.display = checked > 0 ? 'inline-flex' : 'none';
      btn.textContent = '🗑 Delete Selected (' + checked + ')';
    }
  }

  // Bulk delete registrations
  document.addEventListener('click', function(e) {
    if (e.target && e.target.id === 'reg-bulk-delete-btn') {
      const ids = [...document.querySelectorAll('.reg-row-cb:checked')].map(cb => cb.dataset.id);
      if (!ids.length) return;
      if (!confirm('Delete ' + ids.length + ' selected registration(s)? This cannot be undone.')) return;
      Promise.all(ids.map(id => {
        const fd = new FormData();
        fd.append('action', 'yclp_delete_registration');
        fd.append('id', id);
        return fetch(ajax, { method: 'POST', body: fd });
      })).then(() => { loadRegistrations(); });
    }
    if (e.target && e.target.id === 'oto-bulk-delete-btn') {
      const ids = [...document.querySelectorAll('.oto-row-cb:checked')].map(cb => cb.dataset.id);
      if (!ids.length) return;
      if (!confirm('Delete ' + ids.length + ' selected booking(s)? This cannot be undone.')) return;
      Promise.all(ids.map(id => {
        const fd = new FormData();
        fd.append('action', 'yclp_delete_booking');
        fd.append('id', id);
        return fetch(ajax, { method: 'POST', body: fd });
      })).then(() => { loadBookings(); loadAdminCalendar(); });
    }
  });

  // Reset all registrations
  window.resetAllRegistrations = function() {
    if (!confirm('⚠️ WARNING: This will permanently delete ALL workshop registrations from the database. Are you sure?')) return;
    if (!confirm('This is irreversible. Type OK to confirm.')) return;
    const fd = new FormData();
    fd.append('action', 'yclp_reset_registrations');
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => {
        if (res.success) { alert('✅ All registrations deleted.'); loadRegistrations(); }
        else alert('Error: ' + (res.data || 'Unknown'));
      });
  };

  // Reset all OTO bookings
  window.resetAllBookings = function() {
    if (!confirm('⚠️ WARNING: This will permanently delete ALL OTO bookings and free all slots. Are you sure?')) return;
    if (!confirm('This is irreversible. Type OK to confirm.')) return;
    const fd = new FormData();
    fd.append('action', 'yclp_reset_bookings');
    fetch(ajax, { method: 'POST', body: fd })
      .then(r => r.json())
      .then(res => {
        if (res.success) { alert('✅ All bookings deleted.'); loadBookings(); loadAdminCalendar(); }
        else alert('Error: ' + (res.data || 'Unknown'));
      });
  };


})();